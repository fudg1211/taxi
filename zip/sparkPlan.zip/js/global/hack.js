/**
 * Created with IntelliJ IDEA.
 * User: fudongguang
 * Date: 13-1-17
 * Time: 下午3:46
 * 通用函数.
 */
define(['./common'],function (com) {
	var toString = {}.toString,
		UA = window.navigator.userAgent,
		href = window.location.href,
		$ = window.$,
		browserV = $.browser.version.toString(),
		body = $('#body');


	return {};

});
