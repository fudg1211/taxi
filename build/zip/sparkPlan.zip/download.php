<?php

if($_GET['platform']=='android'){
	header("Location: http://yongche.aayongche.com/app/download?app=aa_client&device=android");
}else{
	header("Location: https://itunes.apple.com/cn/app/a-a-yong-che/id651392645?ls=1");
}

?>