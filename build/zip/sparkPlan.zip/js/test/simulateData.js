/**
 * Created with IntelliJ IDEA.
 * User: fudongguang
 * Date: 13-8-30
 * Time: PM2:04
 * To change this template use File | Settings | File Templates.
 */


initData.simulateData = {
	randomGetAward: {"proAbleNum":647,"preNum":13,"notice":"一段测试公告"}
};