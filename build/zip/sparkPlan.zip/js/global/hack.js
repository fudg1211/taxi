define(["./common"],function(){var a=window.$;a("#body");return{}});
