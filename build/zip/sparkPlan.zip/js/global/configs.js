define({host:"./",apiHost:"./",ishopping:"ishopping2://"});
