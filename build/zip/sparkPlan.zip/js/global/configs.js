/**
 * Created with IntelliJ IDEA.
 * User: fudongguang
 * Date: 13-8-16
 * Time: PM7:42
 * To change this template use File | Settings | File Templates.
 */
define({
	host: './',
    apiHost: './',
    ishopping: 'ishopping2://'
});