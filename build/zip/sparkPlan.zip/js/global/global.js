define(["./common","./configs","./storage"],function(b,c,d){var a={};$.extend(a,b,c,d);return a});
