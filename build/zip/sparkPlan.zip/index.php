<?php
header("location:https://itunes.apple.com/cn/app/a-a-yong-che/id651392645?ls=1");
?>