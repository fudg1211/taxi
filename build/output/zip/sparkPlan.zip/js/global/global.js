define(["./common","./configs","./storage","./hack"],function(b,c,d,e){var a={};$.extend(a,b,c,d,e);return a});
